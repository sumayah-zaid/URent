//
//  SelectItem.swift
//  Homepage
//
//  Created by Waad Alsaif on 25/01/2022.
//

import SwiftUI

struct SelectItem: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @State private var itemselected = 0
    @State private var showdate = false
    @State  var dateStart = Date()
    @State  var dateEnd = Date()
    @State var Order = false
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    //    @State private var date = Date()
    var body: some View {

            ZStack{
                myBackgroundColor.ignoresSafeArea()
                ScrollView(showsIndicators: false){
                    
                    
                    VStack{
                        ScrollView(.horizontal) {
                            HStack(spacing: 20) {
                                Image("Mixer") .resizable()
                                    .frame(width: 302, height: 218)
                                Image("Mixxer") .resizable()
                                    .frame(width: 302, height: 218)
                            }
                        }
                        // تعديل الالوان
                        VStack{
                            HStack{
                                VStack(alignment: .leading) {
                                    Text("Mixer").foregroundColor(Color(red: 0.17, green: 0.325, blue: 0.471)).bold()
                                        .font(.title)
                                    HStack{
                                        Text("Kitchen").foregroundColor(Color(red: 0.17, green: 0.325, blue: 0.471))
                                            .font(.callout)
                                        
                                        Text("75SR /day").font(.callout)
                                            .foregroundColor(.gray)
                                        
                                    }
                                    
                                }
                                Spacer()
                                Image(systemName: "heart")
                                Text("4/5") .font(.title3)
                                
                                
                            }
                            
                            HStack{
                                Image("Image-1")
                                    .resizable()
                                    .frame(width: 65, height: 65)
                                    .cornerRadius(8)
                                VStack(alignment: .leading) {
                                    Text("Nourah Mohammed").foregroundColor(Color(red: 0.17, green: 0.325, blue: 0.471))
                                        .font(.title)
                                    HStack{
                                        Image("Image-2")
                                        Text("Riyadh, KSA")
                                            .font(.callout)
                                            .foregroundColor(.gray)
                                    }
                                    
                                    
                                }
                                Spacer()
                                    .font(.largeTitle)
                                
                            }
//                            HStack{
//                                Image(systemName: "calendar")
//                                Button("Date") {
//                                    showdate.toggle()
//                                }
//                                .sheet(isPresented: $showdate) {
//                                    viewDate(TheviewDate: $showdate)
//                                }
//
//                            }  .frame(width: 300, alignment: .topLeading)
//                                .font(.title).foregroundColor(Color(red: 0.17, green: 0.325, blue: 0.471))
                            HStack{
                                Image(systemName: "calender")
                                VStack{
                                    Text("Available Dates")
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                                        .multilineTextAlignment(.leading)
                                        .padding(.trailing, 188.0)
                                    
                                    DatePicker(
                                        "Start Date",
                                        selection: $dateStart ,
                                        displayedComponents: .date
                                    )
                                        .datePickerStyle(.automatic)
                                        .applyTextColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                                        .accentColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                                    DatePicker(
                                        " End Date",
                                        selection: $dateEnd ,
                                        displayedComponents: .date
                                    )
                                        .datePickerStyle(.automatic)
                                        .applyTextColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                                        .accentColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                                }
                            }
                            
                            
                            
                            
                        }
                        
//                        HStack(){
//                            VStack{
//                                Text("Sun")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                Text("16")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                Text("jun")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                
//                            }.padding().background( Rectangle()
//                                                        .fill(Color(red: 0.17, green: 0.325, blue: 0.471))
//                                                        .cornerRadius(8)
//                                                        .frame(width: 48, height: 72)).shadow(color: Color.black.opacity(0.2), radius: 10, x: 10, y: 10)
//                            
//                            Image("arrow").font(.title).foregroundColor(Color(red: 0.17, green: 0.325, blue: 0.471))
//                            VStack{
//                                Text("Sun")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                Text("16")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                Text("jun")
//                                    .font(.headline)
//                                    .foregroundColor(.white)
//                                    .font(.title)
//                                
//                                
//                            }.padding().background( Rectangle()
//                                                        .fill(Color(red: 0.17, green: 0.325, blue: 0.471))
//                                                        .cornerRadius(8)
//                                                        .frame(width: 48, height: 72)).shadow(color: Color.black.opacity(0.2), radius: 10, x: 10, y: 10)
//                        }.padding()
                    }.padding()
                    
                    ScrollView{
                        VStack {
                            Picker("choose your requests or orders", selection: $itemselected) {
                                Text("Description").tag(0)
                                Text("Review").tag(1)
                            }
                            .pickerStyle(.segmented)
                            if itemselected == 0{
                                Des()
                            }else if itemselected==1{
                                Review()
                            }
                        }
                        
                    }
                    
                    Button(action:{
                        Order = true
                    },label: {
                        Text("Order")
                            .font(.headline)
                            .foregroundColor(.white)
                            .fontWeight(.semibold)
                            .padding()
                            .padding(.horizontal,30)
                            .background(
                                Color(red: 0.17, green: 0.325, blue: 0.471)
                                    .cornerRadius(8)
                                    .frame(width: 299, height: 44)
                            )
                        
                    })
                    NavigationLink(
                        destination: PaymentView(),
                      isActive: $Order,
                      label: {
                        
                      })
                    
                }.padding()
                
                
                
            }
    
            .navigationBarBackButtonHidden(true)
                       .navigationBarItems(leading:
                                            HStack{
                            Button(action : {
                           self.mode.wrappedValue.dismiss()
            
                       }){
                         
                       
            VStack{
                     
                     Image(systemName: "chevron.backward")
                         .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                      
                         
                         
                     
            }
            
            }
                           Text("Product Deatils")
                               .font(.headline)
                               .fontWeight(.bold)
                               .padding(.leading, 80.0)
                        
                               
                                           })
        
        
    }
}

struct SelectItem_Previews: PreviewProvider {
    static var previews: some View {
        SelectItem()
    }
}



//Des View

//
//  Des.swift
//  Homepage
//
//  Created by Waad Alsaif on 25/01/2022.
//


struct Des: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    var body: some View {
        ZStack{
            myBackgroundColor.ignoresSafeArea()

        ZStack{
            ContainerRelativeShape()
            .fill(Color(red: Double(241)/255, green: Double(241)/255, blue: (241)/255,opacity: 10))
            .background(Color.gray)
            

              
                .frame(width: 325, height: 130)

  
                Text("Brand : Alsaif-elec , Package weight in KGs : 4, Material : Stainless Steel, Model Number : H90, Type : Stand Mixers, Wattage : 1000 Watt").padding()
                .multilineTextAlignment(.leading)
            }
        }
//            .frame(width: 325, height: 130)
//            .background(Color.)
//                    .clipShape(Rectangle()).shadow(color: Color.black.opacity(0.2), radius: 28)
////
            }
            
        }

//struct Des_Previews: PreviewProvider {
//    static var previews: some View {
//        Des()
//    }
//}

//
//  Review.swift
//  Homepage
//
//  Created by Waad Alsaif on 25/01/2022.
//

//import SwiftUI

struct Review: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @State private var image = "heart"
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]

    var body: some View {
        ZStack{
            myBackgroundColor.ignoresSafeArea()

        
       
            VStack() {
                
                ZStack{
                    ContainerRelativeShape()
                    .fill(Color(red: Double(241)/255, green: Double(241)/255, blue: (241)/255,opacity: 10))
                    .background(Color.gray)
                    
                    VStack(alignment: .leading) {

                        HStack{
                            Image("Image-1")
                                        .resizable()
                                        .frame(width: 31, height: 29)
                            Text("Norah").font(.title).padding(.leastNonzeroMagnitude)
        Spacer()
                            Text("4/5") .font(.caption2).padding(.leastNonzeroMagnitude)
                            Button{
                               
                                if image == "heart"{
                                    image = "heart.fill"}
                                else{
                                    image = "heart"

                                }
                            }label: {
                                Image(systemName: image)
                                    .frame(width: 20, height: 20)
        //                            .padding(.leading,239)
                                    .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            }
                              
                        }
                        .padding()
                        Text("I like this product ")
                                   .font(.subheadline) .foregroundColor(.gray)

                           }
        //                   .padding()
                        }.frame(width:327, height: 101).padding()                .clipShape(Rectangle()).shadow(color: Color.black.opacity(0.2), radius: 28)
                
                
      
                    
            }}
        
    }


struct Review_Previews: PreviewProvider {
    static var previews: some View {
        Review()
    }
}





}


struct viewDate: View {
    @Binding var TheviewDate: Bool
    @State private var date = Date()

    var body: some View {
        NavigationView{
              VStack{
//                Text("Forgot Password").font(.largeTitle).foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                  
                
                  
                          DatePicker(
                                  "Start Date",
                                  selection: $date,
                                  displayedComponents: [.date]
                              )
                              .datePickerStyle(.graphical)
                              .accentColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
          
                Spacer()
                  Button{
                      TheviewDate=false
                              } label: {
                                  Text("Save")
                                      .font(.headline)
                                      .foregroundColor(.white)
                                      .fontWeight(.semibold)
                                      .padding()
                                      .padding(.horizontal,30)
                                      .background(
                                          Color(red: 0.17, green: 0.325, blue: 0.471)
                                              .cornerRadius(8)
                                              .frame(width: 299, height: 44)
                                      )
                                      
                              }
              }
            
              }
    }
}
