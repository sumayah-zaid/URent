//
//  Items.swift
//  URent
//
//  Created by Waad Alsaif on 31/01/2022.
//

import SwiftUI

struct Items: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @State private var itemselected = 0
    var body: some View {
        VStack{
            ZStack{
                myBackgroundColor.ignoresSafeArea()
                ScrollView{
                    VStack {
                        Picker("choose your requests or orders", selection: $itemselected) {
                            Text("Orders").tag(0)
                            Text("Requests").tag(1)
                            Text("Favorites").tag(2)
                            
                        }
                        .pickerStyle(.segmented)
                        if itemselected==0{
                            OrdersView()
                        }else if itemselected==1{
                            RequestView()
                        }else if itemselected==2{
                            FavoritesView()
                            
                        }
                    }
                }
            }
    }.navigationTitle("Items")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct Items_Previews: PreviewProvider {
    static var previews: some View {
        Items()
    }
}
