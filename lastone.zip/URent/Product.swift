
//
//  HomeM.swift
//  Homepage
//
//  Created by Waad Alsaif on 26/01/2022.
//

import Foundation

struct Product: Identifiable{
    var id = UUID()
    var name:  String
    var image: String
    var price: Int
    
}

var productList = [Product(name: "Pan", image: "pan", price: 34),
                   Product(name: "Mixer", image: "Mixer", price: 50),
                   Product(name: "Pizza Oven", image: "PizzaOven", price: 126),
                   Product(name: "Fryer", image: "Fryer", price: 92),
                   Product(name: "PopCorn Macine", image: "PopCorn", price: 84),
                   Product(name: "TeaSet", image: "TeaSet", price: 120),
                   Product(name: "Chips machine", image: "Chips", price: 60),
                   Product(name: "FruitsMixer", image: "FruitsMixer", price: 89),]
