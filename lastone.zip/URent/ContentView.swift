//
//  ContentView.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var tabSelection = 1
   
    var body: some View {
        NavigationView {
            TabView(selection: $tabSelection) {
                HomeView()
                    .tabItem {
                        
                        Image(systemName: "house.fill")
                        Text("Home")
                    }.onTapGesture {
                        tabSelection = 1
                    }
                    .tag(1)
                UploadView()
                    .tabItem {
                        Image(systemName: "plus.circle")
                        Text("Upload")
                    }.onTapGesture {
                        tabSelection = 2
                    }
                    .tag(2)
                Items()
                    .tabItem {
                        Image(systemName: "square.grid.2x2")
                        Text("Item")
                    }.onTapGesture {
                        tabSelection = 3
                    }
                    .tag(3)
                Profile()
                    .tabItem {
                        Image(systemName: "person.fill")
                        Text("Profile")
                    }.onTapGesture {
                        tabSelection = 4
                    }
                    .tag(4)
                
                
            }
            // global, for all child views
            .navigationBarTitle(Text(navigationBarTitle), displayMode: .inline)
      
            .navigationBarHidden(navigationBarHidden)
        
        }
    }
}
    

     
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




//Profile






//Home

//struct Home: View {
//    var body: some View {
//        Text("Home")
//    }
//}
// Favorites
//struct Favorites: View {
//    var body: some View {
//        Text("Fovorites")
//    }
//}

//Item

//struct Item: View {
//    var body: some View {
//        Text("Item")
//    }
//}



private extension ContentView {
    var navigationBarTitle: String {
        var x = ""
        if tabSelection==1{
            x = "Home"
        }
        else if tabSelection==2{
            x = "Upload"
        }
        else if tabSelection==3{
            x = "Items"
        }
        else if tabSelection==4{
            x = "Profile"
        }
        return x
    }
    
    var navigationBarHidden: Bool {
        tabSelection == 5
    }

}


