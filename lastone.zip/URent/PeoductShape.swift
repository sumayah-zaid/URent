//
//  ProductShape.swift
//  test
//
//  Created by Waad Alsaif on 27/01/2022.
//

import SwiftUI

struct ProductShape: View {
    
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    var Product: Product
    
    @State private var image = "heart"

    
    var body: some View {
        ZStack(alignment: .topTrailing){
        ZStack(alignment: .bottom){
            Image(Product.image)
                .resizable()
                .cornerRadius(10)
                .frame(width: 170,height: 143)
                .scaledToFit()
                .padding(.bottom,66)
            VStack(alignment: .leading){
                Text(Product.name)
                    
                    .font(.system(size: 16))
                   .fontWeight(.bold)
                
//                    .frame(width: 100, height: 10)
                   
                HStack{
                Text("\(Product.price)")
                    .font(.caption)
//                    .padding()
                    Text("SR")
                        .font(.system(size: 9))
                }
                
            }
            .padding()
            .frame(width: 180, alignment: .leading)
            
        }
        .frame( height: 220)
//        .shadow(radius: 3)
        .background(.ultraThinMaterial)
        .cornerRadius(10)
    
        .frame(width: 152.5)
        .shadow(radius: 3)
        
        Button{
//            print("Added to faviortie")
           
            if image == "heart"{
                image = "heart.fill"
                
            }
            else{
                image = "heart"

            }
        }label: {
            Image(systemName: image)
                .frame(width: 20, height: 20)
                .padding(.top,180)
                .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                
        }
    }
    }
}


struct ProductShape_Previews: PreviewProvider {
    static var previews: some View {
        ProductShape(Product: productList[0])
    }
}
