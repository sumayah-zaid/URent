//
//  FurnitureShape.swift
//  test
//
//  Created by Waad Alsaif on 28/01/2022.
//

import SwiftUI

struct FurnitureShape: View {
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
            
            let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
            var Furniture: Furniture
            
            @State private var image = "heart"

            
            var body: some View {
                ZStack{
                     Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
                        .ignoresSafeArea()
                
                ZStack(alignment: .topTrailing){
                ZStack(alignment: .bottom){
                    Image(Furniture.image)
                        .resizable()
                        .cornerRadius(10)
                        .frame(width: 170,height: 143)
                        .scaledToFit()
                        .padding(.bottom,66)
                    VStack(alignment: .leading){
                        Text(Furniture.name)
                            
                            .font(.system(size: 16))
                           .fontWeight(.bold)
                        
        //                    .frame(width: 100, height: 10)
                           
                        HStack{
                        Text("\(Furniture.price)")
                            .font(.caption)
        //                    .padding()
                            Text("SR")
                                .font(.system(size: 9))
                        }
                        
                    }
                    .padding()
                    .frame(width: 180, alignment: .leading)
                    
                }
                .frame( height: 220)
        //        .shadow(radius: 3)
                .background(.ultraThinMaterial)
                .cornerRadius(10)
            
                .frame(width: 152.5)
                .shadow(radius: 3)
                
                Button{
        //            print("Added to faviortie")
                   
                    if image == "heart"{
                        image = "heart.fill"}
                    else{
                        image = "heart"

                    }
                }label: {
                    Image(systemName: image)
                        .frame(width: 20, height: 20)
                        .padding(.top,180)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                }
            }
            }
                .navigationBarBackButtonHidden(true)
                           .navigationBarItems(leading:
                                                HStack{
                                Button(action : {
                               self.mode.wrappedValue.dismiss()
                
                           }){
                             
                           
                VStack{
                         
                         Image(systemName: "chevron.backward")
                             .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                          
                             
                             
                         
                }
                
                }
//                               Text("Categories Name")
////                                   .font(.headline)
////                                   .fontWeight(.bold)
////                                   .padding(.leading, 80.0)
                            
                                   
                                               })
            }
        }


struct FurnitureShape_Previews: PreviewProvider {
    static var previews: some View {
        FurnitureShape(Furniture: FurnitureList[0])
    }
}
