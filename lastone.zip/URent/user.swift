import Foundation
import SwiftUI
class account: ObservableObject {
  @Published var account :data
  init(){
    account = .init()
  }
}
//class UploadInfo: ObservableObject {
//  @Published var UploadInfo :upload
//
//  init(){
//    UploadInfo = .init()
//
//  }
//
//}
class data {
  var signIn=false
  var name :String = ""
  var phone:String = ""
  var password:String = ""
  var email:String = ""
  var location:String = ""
  var image = UIImage(named: "Image")!
  var myUpload:[upload]=[]
  var myOrder:[order]=[]
}
class upload : ObservableObject {
    var productName=""
    var image=UIImage(named: "pic")!
    var des=""
    var price=""
    var year=""
    var Brand=""
    var insurance = ""
    enum categoy{
      case Electronics,Kitchen
    }
  }
//struct upload {
//  var items : Array<i>
//  struct item{
//    var productName=“”
//    var image=UIImage(named: “pic”)!
//    var des=“”
//    var price=“”
//    var year=“”
//    var Brand=“”
//    var insurance = “”
//  }
//  }
struct order : Hashable{
  var productName=""
  var Date=""
  var date=""
  var city=""
  var ownerName=""
}
//
//
//struct MyView {
//  let dataFromPreviousView
//  init(
//
//  ) {
//
//  }
//}
