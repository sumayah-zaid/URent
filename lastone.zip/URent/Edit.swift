//
//  Edit.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

struct Edit: View {
    @Environment(\.presentationMode) private var presentationMode
        
    
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @EnvironmentObject var UserModel: account
    @State private var Name = ""
    @State private var Email = ""
    @State private var Phone = ""
    @State var locValue = ""
    @State var value = ""
    @State var errorMessage1 = ""
    @State var errorMessage2 = ""
    @State private var isShowingPhoto = false
 @State private var avatarImage = UIImage(named: "Image")!
   
    @State var save = false
    var list = ["Zulfi", "Tabuk","Taif","Riyadh","Qatif","Najran","Mecca","Medina","Khobar","Khafji","Jubail","Jizan","Jeddah","Dammam","Al Baha","Abha"]
  
    var body: some View {
       
      
            ZStack{
                myBackgroundColor.ignoresSafeArea()
                VStack{
                    
                        
                            ZStack{
                                Image(uiImage: avatarImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .padding()
                            .onTapGesture {
                                
                                isShowingPhoto = true
                                
                            }
                            
                        Image(systemName: "camera.circle.fill").offset(x:25,y:25).font(.system(size: 20))
                 
                        }
                               
                               
                   
                    VStack(alignment: .leading,spacing: 16){
                               
                       
                        Text("Name")
                            .font(.title3)
                            .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        
                        TextField(UserModel.account.name, text: $Name)
                            .frame(width: 326.0, height: 37.0)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        HStack{
                        Text("Phone Number")
                            .font(.title3)
                        .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                            Text(errorMessage1).font(.callout)
                            .foregroundColor(Color.red)}
                        
                        TextField(UserModel.account.phone, text: $Phone)
                            .frame(width: 326.0, height: 37.0)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                      
                       
                        HStack{
                        Text("Email")
                            .font(.title3)
                            .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                            Text(errorMessage2)
                                    .font(.callout)
                                .foregroundColor(Color.red)}
                        TextField(UserModel.account.email, text: $Email)
                            .frame(width: 326.0, height: 37.0)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                     
                    }
                    Divider()
                
                    VStack(alignment: .leading,spacing: 8){
                        HStack{
                        Text("  Location").font(.title3)
                            .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                          
                                    .font(.callout)
                                .foregroundColor(Color.red)}
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                                   .inset(by: 10)
                                   .stroke(Color.gray, lineWidth: 1)
                                   .frame(width: 340, height: 50)
                    Menu {
                        ScrollView{
                        ForEach(list, id: \.self){ client in
                            Button(client) {
                                self.locValue = client
                            }
                        }
                        }
                    } label: {
                        VStack(spacing: 5){
                            
                            HStack{
                                Text(locValue.isEmpty ? UserModel.account.location : locValue)
                                    .foregroundColor(locValue.isEmpty ? .gray : .black)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.282))
                                    .font(Font.system(size: 18, weight: .bold))
                            }
                            .padding(.horizontal)
                        }
                    }
                                
                        }
                        NavigationLink(
                            destination: Profile(),
                                        isActive: $save,
                                        label: {
                                          
                                        })
                            }
                           
                
                    
                    Spacer()
            
                    
                    Button(action:{
                        
//                        errorMessage1 = isPhoneValid2(phoneString: Phone)
//                        errorMessage2 = isValidEmailAddress2(emailAddressString: Email)
//                        UserModel.account.image=avatarImage
//
//
//                        if errorMessage1=="" && errorMessage2==""  {
//                            save=true
//                            if !Name.isEmpty{
//                            UserModel.account.name = Name
//                            }
//                            if !Phone.isEmpty{
//                            UserModel.account.phone = Phone
//                            }
//                            if !Email.isEmpty{
//                            UserModel.account.email = Email
//                            }
//                            if !locValue.isEmpty{
//                            UserModel.account.location = locValue
//                            }
                        
                        presentationMode.wrappedValue.dismiss()
                                } ,label: {
                                    Text("Save")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                        .padding()
                                        .padding(.horizontal,30)
                                        .background(
                                            Color(red: 0.17, green: 0.325, blue: 0.471)
                                                .cornerRadius(8)
                                                .frame(width: 299, height: 44)
                                        )
                                        
                                })

    
        
        
  
    
    }.padding(.horizontal, 32.0)
    }
            .navigationBarTitle("Edit Profile",displayMode: .inline)
           
            .sheet(isPresented:$isShowingPhoto, content: {
                PhotoPicker(avatrImage: $avatarImage)
    })
}
    }


struct Edit_Previews: PreviewProvider {
    static var previews: some View {
        Edit()
    }
}

func isValidEmailAddress2(emailAddressString: String) -> String {
        
        var message = ""
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.(com)"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
           
            if results.count == 0
            {
                message = "(Email Address is Invalid)"
            }
            if emailAddressString.isEmpty{
                message = ""
                
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
           
        }
        
        return  message
    }


func isPhoneValid2(phoneString: String) -> String {
        
        var message = ""
        let phoneRegEx = "^((\\+)|(05))[0|3|4|5|6|7|8|9]{1}[0-9]{7}$"
    
    
        
        do {
            let regex = try NSRegularExpression(pattern: phoneRegEx)
            let nsString = phoneString as NSString
            let results = regex.matches(in: phoneString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                message = "(Number is Invalid)"
            }
            if phoneString.isEmpty{
                message=""
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
         
        }
        
        return  message
    }
