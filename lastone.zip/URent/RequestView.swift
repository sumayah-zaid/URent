//
//  RequestView.swift
//  UrentLama
//
//  Created by Lama Doughan on 29/01/2022.
//

import SwiftUI

struct RequestView: View {
    
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    //headset
    @State var isClicked = false
    @State var check = false
    @State var x = false
    @State var image = Image(systemName: "checkmark.circle")
    @State var showAlertAccept = false
    @State var showAlertReject = false
    //macbook
    @State var isClicked1 = false
    @State var check1 = false
    @State var x1 = false
    @State var image1 = Image(systemName: "checkmark.circle")
    @State var showAlertAccept1 = false
    @State var showAlertReject1 = false
    //pan
    @State var isClicked2 = false
    @State var check2 = false
    @State var x2 = false
    @State var image2 = Image(systemName: "checkmark.circle")
    @State var showAlertAccept2 = false
    @State var showAlertReject2 = false
    
    
    var body: some View {
        
        VStack{
            ZStack{
                myBackgroundColor.ignoresSafeArea()
                
                ScrollView{
                    VStack(spacing:16){
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            
                            HStack(spacing:60){
                                HStack{
                                    Image("headset_L")
                                    
                                    VStack(alignment: .leading,spacing: 8){
                                        Text("Headset")
                                            .font(.system(size: 17))
                                        
                                        Text("14 Oct - 16 Oct")
                                            .font(.system(size: 14))
                                    }
                                }.padding(.leading)
                                
                                HStack{
                                    Button(action:{
                                        if !check{
                                        showAlertAccept = true
                                        }
                                    },label:
                                            {
                                        if !isClicked{
                                            Image(systemName: "checkmark.circle")
                                                .foregroundColor(Color.green)
                                            .font(.system(size: 28))
                                        }
                                        
                                        if check{
                                            VStack(spacing:8){
                                                Text("Accepted")
                                                    .foregroundColor(Color.green)
                                                Image(systemName: "message.fill")
                                                    .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                                            }
                                        }
                                    }
                                    ).alert( isPresented: $showAlertAccept, content: {
                                        Alert(title:Text("Accept Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                            Text("Accept"), action: {
                                                check = true
                                                isClicked = true
                                            })
                                        )}
                                    )
                                    
                                    Button(action:{
                                        if !x{
                                        showAlertReject = true
                                        }
                                        
                                    },label:{
                                        if !isClicked{
                                            Image(systemName: "x.circle")
                                                .foregroundColor(Color.red)
                                            .font(.system(size: 28))
                                        }
                                        
                                        if x{
                                            VStack(spacing:8){
                                                Text("Rejected")
                                                .foregroundColor(Color.red)}
                                        }
                                    }).alert( isPresented: $showAlertReject, content: {
                                            Alert(title:Text("Reject Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                                Text("Reject"), action: {
                                                    x = true
                                                    isClicked = true
                                                })
                                            )})
                                }.padding(.trailing)
                            }.frame(alignment: .leading)
                        }
                        ////////////
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            
                            HStack(spacing:56){
                                HStack{
                                    Image("macbook_L")
                                    
                                    VStack(alignment: .leading,spacing: 8){
                                        Text("MacBook Pro ")
                                            .font(.system(size: 17))
                                        Text("10 Jan - 14 Jan")
                                            .font(.system(size: 14))
                                    }
                                }.padding(.leading)
                                
                                HStack{
                                    Button(action:{
                                        if !check1{
                                        showAlertAccept1 = true
                                        }
                                    },label:
                                            {
                                        if !isClicked1{
                                            Image(systemName: "checkmark.circle")
                                                .foregroundColor(Color.green)
                                            .font(.system(size: 28))
                                        }
                                        
                                        if check1{
                                            VStack(spacing:8){
                                                Text("Accepted")
                                                    .foregroundColor(Color.green)
                                                Image(systemName: "message.fill")
                                                    .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                                            }
                                        }
                                    }
                                    ).alert( isPresented: $showAlertAccept1, content: {
                                        Alert(title:Text("Accept Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                            Text("Accept"), action: {
                                                check1 = true
                                                isClicked1 = true
                                            })
                                        )}
                                    )
                                    
                                    Button(action:{
                                        if !x1{
                                        showAlertReject1 = true
                                        }
                                        
                                    },label:{
                                        if !isClicked1{
                                            Image(systemName: "x.circle")
                                                .foregroundColor(Color.red)
                                            .font(.system(size: 28))
                                        }
                                        if x1{
                                            VStack(spacing:8){
                                                Text("Rejected")
                                                .foregroundColor(Color.red)}
                                        }
                                    }).alert( isPresented: $showAlertReject1, content: {
                                            Alert(title:Text("Reject Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                                Text("Reject"), action: {
                                                    x1 = true
                                                    isClicked1 = true
                                                })
                                            )})
                                }.padding(.trailing)
                            }.frame(alignment: .leading)
                        }
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            
                            HStack(spacing:66){
                                HStack{
                                    Image("table_L")
                                    
                                    VStack(alignment: .leading,spacing: 8){
                                        Text("White Table")
                                            .font(.system(size: 17))
                                        Text("5 Mar - 10 Mar")
                                            .font(.system(size: 14))
                                    }
                                }.padding(.leading)
                                
                                VStack(spacing:8){
                                    Text("Accepted")
                                        .foregroundColor(Color.green)
                                    Image(systemName: "message.fill")
                                        .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                                }.padding(.trailing)
                            }
                        }
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            
                            HStack(spacing:60){
                                HStack{
                                    Image("pan_L")
                                    
                                    VStack(alignment: .leading,spacing: 8){
                                        Text("Pan")
                                            .font(.system(size: 17))
                                        
                                        Text("11 May - 15 May")
                                            .font(.system(size: 14))
                                    }
                                }.padding(.leading)
                                
                                HStack{
                                    Button(action:{
                                        showAlertAccept2 = true
                                    },label:
                                            {
                                        if !isClicked2{
                                            Image(systemName: "checkmark.circle")
                                                .foregroundColor(Color.green)
                                            .font(.system(size: 28))
                                        }
                                        if check2{
                                            VStack(spacing:8){
                                                Text("Accepted")
                                                    .foregroundColor(Color.green)
                                                
                                                Image(systemName: "message.fill")
                                                    .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                                            }
                                        }
                                    }
                                    ).alert( isPresented: $showAlertAccept2, content: {
                                        Alert(title:Text("Accept Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                            Text("Accept"), action: {
                                                check2 = true
                                                isClicked2 = true
                                            })
                                        )}
                                    )
                                    
                                    Button(action:{
                                        showAlertReject2 = true
                                        
                                    },label:{
                                        if !isClicked2{
                                            Image(systemName: "x.circle")
                                                .foregroundColor(Color.red)
                                            .font(.system(size: 28))
                                        }
                                        if x2{
                                            VStack(spacing:8){
                                                Text("Rejected")
                                                .foregroundColor(Color.red)}
                                        }
                                    }).alert( isPresented: $showAlertReject2, content: {
                                            Alert(title:Text("Reject Request?"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                                                Text("Reject"), action: {
                                                    x2 = true
                                                    isClicked2 = true
                                                })
                                            )})
                                }.padding(.trailing)
                            }.frame(alignment: .leading)
                        }
                    }.padding(.top)
                }
            }.navigationTitle("Items")
             .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct RequestView_Previews: PreviewProvider {
    static var previews: some View {
        RequestView()
    }
}
