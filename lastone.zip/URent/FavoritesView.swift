//
//  FavoritesView.swift
//  UrentLama
//
//  Created by Lama Doughan on 29/01/2022.
//

import SwiftUI

struct FavoritesView: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @State private var image = "heart.fill"
    @State private var image2 = "heart.fill"

    var body: some View {
        
        
        VStack{
            ZStack{
                myBackgroundColor.ignoresSafeArea()
                ScrollView{
                    VStack(spacing:16){
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            HStack(spacing:72){
                                HStack{
                                    Image("nikon_L")
                                    
                                    Text("Camera Nikon Z6")
                                        .font(.system(size: 17))
                                    
                                }.padding(.leading)
                                
                                
                                
                                HStack{
                                    Image(systemName: "heart.fill")
                                        .foregroundColor(Color(red: 0.005, green: 0.156, blue: 0.288))
                                        .font(.system(size: 20))
                                    
                                }.padding(.trailing)
                                
                            }.frame(maxWidth:.infinity)
                        }
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            HStack(spacing:62){
                                HStack{
                                    Image("dj_L")
                                    
                                    Text("DJ Equalizer Set\t")
                                        .font(.system(size: 17))
                                    
                                }.padding(.leading)
                                
                                HStack{
                                    Button{
//                                        if image == "heart"{
                                            image = "heart.fill"
                                        
//                                    }
//                                        else{
//                                            image = "heart"
//                                        }
                                    }label: {
                                        Image(systemName: image)
                                            .frame(width: 20, height: 20)
                                        
                                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                                    }
                                }.padding(.trailing)
                            }.frame(alignment: .leading)
                        }
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                                .frame(width: 326, height: 80)
                            HStack(spacing:102){
                                HStack{
                                    Image("carpentry_L")
                                    
                                    Text("Carpentry Kit")
                                        .font(.system(size: 17))
                                    
                                }.padding(.leading)
                                
                                HStack{
                                    Button{
                                        if image2 == "heart.fill"{
                                            image2 = "heart"}
                                        else{
                                            image2 = "heart"
                                        }
                                    }label: {
                                        Image(systemName: image2)
                                            .frame(width: 20, height: 20)
                                        
                                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                                    }
                                }.padding(.trailing)
                            }
                        }
                    }.padding(.top)
                }
            }
        }
    }
}


struct FavoritesView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesView()
    }
}
