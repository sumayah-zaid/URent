//
//  KitchenEquipmentView.swift
//  test
//
//  Created by Waad Alsaif on 27/01/2022.
//

import SwiftUI

struct KitchenEquipmentView: View {
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]
    var body: some View {
        ZStack{
             Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
                .ignoresSafeArea()
            ScrollView (showsIndicators: false){
        LazyVGrid(columns: columns, spacing: 20){

            ForEach(productList, id: \.id){ Product in ProductShape(Product: Product)
                
            }
            
        }
        .padding()
//            }
//            .navigationTitle("Kitchen Equipmen")
//            .navigationBarTitleDisplayMode(.inline)
        }
        
    }
        .navigationBarBackButtonHidden(true)
                   .navigationBarItems(leading:
                                        HStack{
                        Button(action : {
                       self.mode.wrappedValue.dismiss()
        
                   }){
                     
                   
        VStack{
                 
                 Image(systemName: "chevron.backward")
                     .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                  
                     
                     
                 
        }
        
        }
                       Text("Kitchen Equipmen")
                           .font(.headline)
                           .fontWeight(.bold)
                           .padding(.leading, 80.0)
                    
                           
                                       })
            
        
    }
}

struct KitchenEquipmentView_Previews: PreviewProvider {
    static var previews: some View {
        KitchenEquipmentView()
    }
}
