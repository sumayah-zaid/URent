//
//  Signup.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

struct Singup: View{
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @Binding var isShowingRegisterationForm : Bool
    @EnvironmentObject var UserModel: account
    @State var signUp = false
    @State private var Name = ""
    @State private var Email = ""
    @State private var Phone = ""
    @State private var pass1 = ""
    @State private var pass2 = ""
    @State private var locValue = ""
    var location = "Select Location"
    var list = ["Zulfi", "Tabuk","Taif","Riyadh","Qatif","Najran","Mecca","Medina","Khobar","Khafji","Jubail","Jizan","Jeddah","Dammam","Al Baha","Abha"]
    @State var errorMessage1 = ""
    @State var errorMessage2 = ""
    @State var errorMessage3 = ""
    @State var errorMessage4 = ""
    @State var errorMessage5 = ""
    @State var errorMessage6 = ""
   
    var body: some View {
       
            ZStack{
                myBackgroundColor.ignoresSafeArea()
               
                 
                VStack{
                 
                VStack(alignment: .leading,spacing: 12) {
                    HStack{
                    Text("Name")
                        .font(.title3)
                        .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                    Text(errorMessage1)
                            .font(.callout)
                        .foregroundColor(Color.red)}
                    TextField("Enter Name...", text: $Name)
                        .frame(width: 326.0, height: 37.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    HStack{
                    Text("Phone Number")
                        .font(.title3)
                    .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        Text(errorMessage2).font(.callout)
                        .foregroundColor(Color.red)}
                    
                    TextField("Enter Phone Number...", text: $Phone)
                        .frame(width: 326.0, height: 37.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    HStack{
                    Text("Password")
                        .font(.title3)
                        .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        Text(errorMessage3)
                                .font(.callout)
                            .foregroundColor(Color.red)}
                    TextField("Enter Password...", text: $pass1)
                        .frame(width: 326.0, height: 37.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    HStack{
                    Text("Confirm Password")
                        .font(.title3)
                        .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        Text(errorMessage4)
                                .font(.callout)
                            .foregroundColor(Color.red)}
                    TextField("Re Password...", text: $pass2)
                        .frame(width: 326.0, height: 37.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    HStack{
                    Text("Email")
                        .font(.title3)
                        .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        Text(errorMessage5)
                                .font(.callout)
                            .foregroundColor(Color.red)}
                    TextField("Enter Email...", text: $Email)
                        .frame(width: 326.0, height: 37.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                 
                }
                    NavigationLink(destination:SignIn()){
                        Text("Already hava an Account?").offset(x:-70)
                            
                        
                    }
                    Divider()
                
                    VStack(alignment: .leading,spacing: 8){
                        HStack{
                        Text("  Location").font(.title3)
                            .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                            Text(errorMessage6)
                                    .font(.callout)
                                .foregroundColor(Color.red)}
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                                   .inset(by: 10)
                                   .stroke(Color.gray, lineWidth: 1)
                                   .frame(width: 340, height: 50)
                    Menu {
                        ScrollView{
                        ForEach(list, id: \.self){ client in
                            Button(client) {
                                self.locValue = client
                            }
                        }
                        }
                    } label: {
                        VStack(spacing: 5){
                            
                            HStack{
                                Text(locValue.isEmpty ? location : locValue)
                                    .foregroundColor(locValue.isEmpty ? .gray : .black)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.282))
                                    .font(Font.system(size: 18, weight: .bold))
                            }
                            .padding(.horizontal)

                                
                        }
                    }}
                    }.padding(.horizontal, 32.0)

                    Button{
                                    
                                } label: {
                                    ZStack{
                                    Text("Sign Up with Apple")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                        .padding()
                                        .padding(.horizontal,30)
                                        .background(Color.black
                                                .cornerRadius(8)
                                                .frame(width: 299, height: 44)
                                        )
                                        Image(systemName:"applelogo").foregroundColor(Color.white).offset(x:-90)                                }
                                }
                  
                    
                    Button(action: {

                     errorMessage1=isNameValid(nameString: Name)
                     errorMessage2 = isPhoneValid(phoneString: Phone)
                     errorMessage3 = isPassValid(passString: pass1)
                     errorMessage4 = isConfirmValid(pass1:pass1,pass2: pass2)
                     errorMessage5 = isValidEmailAddress(emailAddressString: Email)
                     errorMessage6 = isLocationValid(location: locValue)

                        if errorMessage1=="" && errorMessage2=="" && errorMessage3=="" && errorMessage4=="" && errorMessage5=="" && errorMessage6==""{

                            UserModel.account.signIn=true
                            UserModel.account.name = Name
                            UserModel.account.phone = Phone
                            UserModel.account.password = pass1
                            UserModel.account.email = Email
                            UserModel.account.location = locValue
//                           UserModel.account.order.append(order(productName: "", price: "", date: "", city: "", ownerName: ""))
//
                        signUp = true
                   
                    }
                    
                    },label:{ ZStack{
                        Text("Sign Up")
                            .font(.headline)
                            .foregroundColor(.white)
                            .fontWeight(.semibold)
                            .padding()
                            .padding(.horizontal,30)
                            .background(
                                Color(red: 0.17, green: 0.325, blue: 0.471)
                                    .cornerRadius(8)
                                    .frame(width: 299, height: 44)
                            )
                            
                    }} )
                    NavigationLink(
                        destination: Code( isShowingRegisterationForm : $isShowingRegisterationForm ),
                      isActive: $signUp,
                      label: {
                        
                      })

               
                    
                }.padding(.top, 32.0)
               
                }
                    
            .navigationBarTitle("",displayMode:.inline)
            
         
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Sign Up")
                        .font(.largeTitle.bold())
                        .frame(width: 200.0) .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        .accessibilityAddTraits(.isHeader)
                }
            }
                
        
  }
 }

        

        
    

struct Signup_Previews: PreviewProvider {
    static var previews: some View {
        Singup(isShowingRegisterationForm: .constant(true))
    }
}






    
func isNameValid(nameString: String)->String{
    var message=""
    if nameString.isEmpty {
        message = "(Enter Name)"
    }
    return message
}
func isValidEmailAddress(emailAddressString: String) -> String {
        
        var message = ""
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.(com)"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
           
            if results.count == 0
            {
                message = "(Email Address is Invalid)"
            }
            if emailAddressString.isEmpty{
                message = "(Enter Email Address)"
                
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
           
        }
        
        return  message
    }


func isPhoneValid(phoneString: String) -> String {
        
        var message = ""
        let phoneRegEx = "^((\\+)|(05))[0|3|4|5|6|7|8|9]{1}[0-9]{7}$"
    
    
        
        do {
            let regex = try NSRegularExpression(pattern: phoneRegEx)
            let nsString = phoneString as NSString
            let results = regex.matches(in: phoneString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                message = "(Number is Invalid)"
            }
            if phoneString.isEmpty{
                message="(Enter Phone Number)"
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
         
        }
        
        return  message
    }



func isPassValid(passString: String) ->String{
    var message=""
    if passString.isEmpty{
        message="(Enter Password)"
    }
    return message
}

func isConfirmValid (pass1:String,pass2:String)->String{
    var message=""
    if pass1 != pass2{
        message="(Password Mismatch)"
    }
   return message
}
func isLocationValid(location: String)->String{
    var message=""
    if location.isEmpty {
        message="(Select Location)"
    }
    return message
}
