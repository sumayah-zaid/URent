//
//  UploadView.swift
//  Reegister
//
//  Created by Danya T on 24/06/1443 AH.
//

import SwiftUI

//-------Page 1---------------
struct UploadView: View {
  let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
 @EnvironmentObject var UserModel: account
 @State private var isShowingRegisterationForm = false
 @State private var showAlert = false
 @State var signup = false
 @State private var isShowingPhoto = false
 @State private var productImage = UIImage(named: "pic")!
 @State var isActive : Bool = false
    @EnvironmentObject var productInfo: upload


  var body: some View {
 
    ZStack{
      myBackgroundColor.ignoresSafeArea()
      VStack{
          VStack{
         Rectangle()
          .fill(Color.gray)
          .frame(width: 271.0, height: 2.0)
          .overlay(){
            HStack(spacing: 129.0){
              Circle()
                .fill(Color(red: 0.17, green: 0.325, blue: 0.471))
                .frame(width: 9, height: 9)
              Circle()
                .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                .frame(width: 9, height:9)
              Circle()
                .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                .frame(width: 9.0, height: 9.0)
            }
          }
          
        Text("Upload Picture")
          .font(.caption)
          .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
          .padding(.trailing,270)
         .frame(height:50)
      }
          .padding(.top,15)
          
//          Spacer()
        Text("Upload Product’s picture")
          .font(.system(size: 22))
          .fontWeight(.semibold)
          .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
          .multilineTextAlignment(.leading)
          
              
              
            Button{
                if UserModel.account.signIn == false{
              showAlert.toggle()
                    
                }
                else{
                    isShowingPhoto=true
                   
                }
               
            }label: {
                

                Image(uiImage: productImage)
            .resizable()
            .scaledToFill()
            .frame(width: 325, height: 216)
            .clipShape(RoundedRectangle(cornerRadius: 10))
                
            
                
                
            }.alert( isPresented: $showAlert, content: {
                Alert(title:Text("Do you have an account"), message: nil, primaryButton: .cancel(), secondaryButton: .default(
                Text("Sign up"), action: {
                  isShowingRegisterationForm = true
                   
                })
              )}
            )
          
          
          
          
            NavigationLink(
              destination: Upload(),
              isActive: $signup,
              label: {
              }
            )
         
          Spacer()
        
        Button{
            productInfo.image = productImage
            
            signup = true
        } label: {
          Text("Next")
            .font(.headline)
            .foregroundColor(.white)
            .fontWeight(.semibold)
            .padding()
            .padding(.horizontal,30)
            .background(
              Color(red: 0.17, green: 0.325, blue: 0.471)
                .cornerRadius(8)
                .frame(width: 299, height: 44)
            )
        }
        
      }.padding(.horizontal, 32.0)
        
      
        
    }
    .fullScreenCover(isPresented: $isShowingRegisterationForm, content: {
        
        NavigationView{
            Singup(isShowingRegisterationForm: $isShowingRegisterationForm)
        }
    })
     
          .navigationBarBackButtonHidden(true)
        
    .sheet(isPresented:$isShowingPhoto, content: {
        PhotoPicker2(productImage: $productImage)
})
    }
          
}


//-------Page 2---------------


struct Upload: View {
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @EnvironmentObject var UserModel: account
    @EnvironmentObject var productInfo: upload


//    @EnvironmentObject var UserModel2: UploadInfo
//    @ObservedObject var Lmodel = Model()
    @State private var locValue = ""
    var location = "Select Location"
    var list = ["Zulfi", "Tabuk","Taif","Riyadh","Qatif","Najran","Mecca","Medina","Khobar","Khafji","Jubail","Jizan","Jeddah","Dammam","Al Baha","Abha"]
    @State private var Pname:String = ""
    @State private var year:String = ""
    @State private var Brand:String = ""
    @State private var Discription:String=""
    @State var page3 = false
    @State private var catValue = ""
    var category = "Select Category"
    var clist = ["Kitchen", "Garden","Games","Furniture","Electonic Deivces","Sport"]
//    @EnvironmentObject var productInfo: upload
    
    
    var body: some View {
        
        ZStack{
            Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
                .ignoresSafeArea()
            VStack(spacing :40){
                VStack{
                    Rectangle()
                        .fill(Color.gray)
                        .frame(width: 271.0, height: 2.0)
                        .overlay(){
                            HStack(spacing: 123.0){
                                Circle()
                                    .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                                    .frame(width: 9.0, height: 9.0)
                                
                                Circle()
                                    .fill(Color(red: 0.213, green: 0.317, blue: 0.463))
                                    .frame(width: 9.0, height: 9.0)
                                Circle()
                                    .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                                    .frame(width: 9.0, height: 9.0)
                                
                            }
                        }
                    Text("Product Information")
                        .font(.caption)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                }
                .padding(.top,20)

              
                VStack{
                    Text("Prouduct Information")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 155.0)
                    
                    
                    ZStack{
                        TextField("", text: $Pname)
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if Pname.isEmpty{
                                Text("Name of the product").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 150.0)
                            }
                            
                        }
                        
                    }
                    ZStack{
                        TextField("", text: $year)
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if year.isEmpty{
                                Text("Year of Purchase").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 179.0)
                            }
                            
                        }
                        
                    }
                    ZStack{
                        TextField("", text:$Brand )
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if Brand.isEmpty{
                                Text("Prouduct's Brand").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 175.0)
                            }
                            
                        }
                        
                    }
                    ZStack{
                        TextField("", text: $Discription)
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 123.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if Discription.isEmpty{
                                Text("Discription").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 224.0)
                            }
                            
                        }
                        
                    }
                    ZStack{
                        
                        Text("")
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.700))
                        
                            .padding(.trailing, 190.0)
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        
                        Menu {
                            ScrollView{
                            ForEach(clist, id: \.self){ client in
                                Button(client) {
                                    self.catValue = client
                                }
                            }
                            }
                        } label: {
                            VStack(spacing: 5){
                                
                                HStack{
                                    Text(catValue.isEmpty ? category : catValue)
                                        .foregroundColor(catValue.isEmpty ? Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771): .black)
//                                        .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771))
                                        .padding(.trailing, 110.0)
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.282))
                                        .font(Font.system(size: 10, weight: .bold))
                                        .padding(.leading,50)
                                }
                                

                                    
                            }
                        }                  }
                    
                    Text("Location Information")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 155.0)
                        .padding(.top, 30.0)
                    ZStack{
                        
                        Text("")
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.700))
                        
                            .padding(.trailing, 190.0)
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        
                        Menu {
                            ScrollView{
                            ForEach(list, id: \.self){ client in
                                Button(client) {
                                    self.locValue = client
                                }
                            }
                            }
                        } label: {
                            VStack(spacing: 5){
                                
                                HStack{
                                    Text(locValue.isEmpty ? location : locValue)
                                        .foregroundColor(locValue.isEmpty ? Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771): .black)
//                                        .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771))
                                        .padding(.trailing, 110.0)
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.282))
                                        .font(Font.system(size: 10, weight: .bold))
                                        .padding(.leading,50)
                                }
                                

                                    
                            }
                        }                  }

                }
                .padding(.bottom, 30.0)
                VStack{
                    Button(action:{
                        productInfo.productName = Pname
                       productInfo.year = year
                        productInfo.Brand = Brand
                         productInfo.des = Discription
                        page3 = true

                    },

                           label: {

                        VStack{
                            Text("Next")
                                .font(/*@START_MENU_TOKEN@*/.headline/*@END_MENU_TOKEN@*/)
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .frame(width: 299, height: 44.0)
                                .background(Color(red: 0.21, green: 0.32, blue: 0.46))
                                .cornerRadius(/*@START_MENU_TOKEN@*/11.0/*@END_MENU_TOKEN@*/)
                        }
                    })
                    
                        
                    NavigationLink(destination:Upload_2(),isActive: $page3,label: {})
                    
                    
                    
                }
                .padding(.bottom, 60.0)

            }
            
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
                                HStack{
            Button(action : {
                self.mode.wrappedValue.dismiss()

            }){
                VStack{
                    Image(systemName: "chevron.backward")
                        .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                }
            }
            Text("Upload")
                .font(.headline)
                .fontWeight(.bold)
                .padding(.leading, 120.0)
        })
        
    }
}

//-----------page 3 --------------
extension View {
    @ViewBuilder func applyTextColor(_ color: Color) -> some View {
        if UITraitCollection.current.userInterfaceStyle == .light {
            self.colorInvert().colorMultiply(color)
        } else {
            self.colorMultiply(color)
        }
    }
}
struct Upload_2: View {
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @EnvironmentObject var UserModel: account
//    @EnvironmentObject var UserModel2: UploadInfo
    @State  var dateStart = Date()
    @State  var dateEnd = Date()
    @State  var Price:String = ""
    @State  var Insurance:String = ""
    @State var profile = false
    @EnvironmentObject var productInfo: upload
    @State private var dValue = ""
    var delivery = "Delivery Options "
    var dlist = ["Pick up", "Delivery"]
    var body: some View {
        ZStack{
            Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
                .ignoresSafeArea()
            VStack(spacing:40){
                VStack{
                    Rectangle()
                        .fill(Color.gray)
                        .frame(width: 271.0, height: 2.0)
                        .overlay(){
                            HStack(spacing: 123.0){
                                Circle()
                                    .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                                    .frame(width: 9.0, height: 9.0)
                                
                                Circle()
                                    .fill(Color(red: 0.7490196078431373, green: 0.7490196078431373, blue: 0.7490196078431373))
                                    .frame(width: 9.0, height: 9.0)
                                Circle()
                                    .fill(Color(red: 0.213, green: 0.317, blue: 0.463))
                                    .frame(width: 9.0, height: 9.0)
                            }
                        }
                    Text("Product’s price")
                        .font(.caption)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .padding(.leading, 239.0)
                }
                .padding(.top,37)
                VStack(spacing:30){
                VStack{
                    Text("Available Dates")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 188.0)
                    
                    DatePicker(
                        "Start Date",
                        selection: $dateStart ,
                        displayedComponents: .date
                    )
                        .datePickerStyle(.automatic)
                        .applyTextColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .accentColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                    DatePicker(
                        " End Date",
                        selection: $dateEnd ,
                        displayedComponents: .date
                    )
                        .datePickerStyle(.automatic)
                        .applyTextColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .accentColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                }
                .padding(.leading,32)
                .padding(.trailing, 32)
                
                VStack{
                    Text("Prouduct Price")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 206.0)
                                      ZStack{
                        TextField("", text: $Price)
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if Price.isEmpty{
                                Text("Per Day").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 238.0)
                            }
                        }
                    }
                }
                VStack{
                    Text("Insurance")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 245.0)
                    ZStack{
                        TextField("", text: $Insurance)
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463))
                            .padding([.top, .leading, .bottom])
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        HStack{
                            if Insurance.isEmpty{
                                Text("00.00").foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771)).padding(.trailing, 238.0)
                            }
                        }
                    }
                }
                VStack{
                    Text("Delivery ")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.00784313725490196, green: 0.16470588235294117, blue: 0.2901960784313726))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing, 259.0)
                    ZStack{
                        
                        Text("")
                            .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.700))
                        
                            .padding(.trailing, 190.0)
                            .frame(width: 328.0, height: 40.0)
                            .border(Color(red: 0.00392156862745098, green: 0.16470588235294117, blue: 0.2901960784313726, opacity: 0.419), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                            .cornerRadius(/*@START_MENU_TOKEN@*/2.0/*@END_MENU_TOKEN@*/)
                        
                        Menu {
                            ScrollView{
                            ForEach(dlist, id: \.self){ client in
                                Button(client) {
                                    self.dValue = client
                                }
                            }
                            }
                        } label: {
                            VStack(spacing: 5){
                                
                                HStack{
                                    Text(dValue.isEmpty ? delivery : dValue)
                                        .foregroundColor(dValue.isEmpty ? Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771): .black)
//                                        .foregroundColor(Color(red: 0.213, green: 0.317, blue: 0.463, opacity: 0.771))
                                        .padding(.trailing, 110.0)
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.282))
                                        .font(Font.system(size: 10, weight: .bold))
                                        .padding(.leading,50)
                                }
                                

                                    
                            }
                        }                  }
                }
            }
                .padding(.bottom, 30.0)

                VStack{
                    Button(action: {
                        productInfo.price = Price
                        productInfo.insurance = Insurance
                        profile = true
                        UserModel.account.myUpload.append(productInfo)


                    },label: {

                        VStack{
                            Text("Upload")
                                .font(/*@START_MENU_TOKEN@*/.headline/*@END_MENU_TOKEN@*/)
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .frame(width: 299, height: 44.0)
                                .background(Color(red: 0.21, green: 0.32, blue: 0.46))
                                .cornerRadius(/*@START_MENU_TOKEN@*/11.0/*@END_MENU_TOKEN@*/)
                        }
                    }
                    )
                }
                .padding(.top, 25)
                NavigationLink(destination: ContentView(), isActive: $profile, label: {})
                NavigationLink(
                    destination: ContentView(),
//                        .environmentObject(UserModel)
                    label: {
//                        VStack{
//                            Text("Upload")
//                                .font(/*@START_MENU_TOKEN@*/.headline/*@END_MENU_TOKEN@*/)
//                                .fontWeight(.bold)
//                                .foregroundColor(Color.white)
//                                .frame(width: 299, height: 44.0)
//                                .background(Color(red: 0.21, green: 0.32, blue: 0.46))
//                                .cornerRadius(/*@START_MENU_TOKEN@*/11.0/*@END_MENU_TOKEN@*/)
//                        }

                    })
                    .onTapGesture {
//                        UserModel.account.price = Price
//                        UserModel2.UploadInfo.insurance = Insurance
//                        UserModel.account.myUpload.append(upload(productName: UserModel2.UploadInfo.productName, image: UserModel2.UploadInfo.image, des: UserModel2.UploadInfo.des, price: UserModel2.UploadInfo.price, year: UserModel2.UploadInfo.year, Brand: UserModel2.UploadInfo.Brand, insurance: UserModel2.UploadInfo.insurance))
//                        productInfo.price = Price
//                        productInfo.insurance = Insurance
//
//                        UserModel.account.myUpload.append(productInfo)
//                        UserModel.account.myUpload.append(upload(price: UserModel.account.price))
                    }
            }
            
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
                                HStack{
            Button(action : {
                self.mode.wrappedValue.dismiss()

            }){
                VStack{
                    Image(systemName: "chevron.backward")
                        .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                }
            }
            Text("Upload")
                .font(.headline)
                .fontWeight(.bold)
                .padding(.leading, 120.0)
        })
    }
}




struct UploadView_Previews: PreviewProvider {
    static var previews: some View {
        UploadView()
    }
}
