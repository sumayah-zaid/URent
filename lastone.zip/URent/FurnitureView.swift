//
//  FurnitureView.swift
//  test
//
//  Created by Waad Alsaif on 28/01/2022.
//

import SwiftUI

struct FurnitureView: View {
        
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]
    
    
    var body: some View {
//        NavigationView{
            ScrollView{
        LazyVGrid(columns: columns, spacing: 20){

            ForEach(FurnitureList, id: \.id){ Furniture in FurnitureShape(Furniture: Furniture)
                
            }
            
        }
        .padding()
//            }
            .navigationTitle("Furniture")
            .navigationBarTitleDisplayMode(.inline)
        }
        
     
            
    }
    
}


struct FurnitureView_Previews: PreviewProvider {
    static var previews: some View {
        FurnitureView()
    }
}
