//
//  HomeView.swift
//  Homepage
//
//  Created by Waad Alsaif on 20/01/2022.
//

import SwiftUI

let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)

struct HomeView: View {
    @State private var image = "heart"

    var body: some View{

        VStack{
            
            
            ZStack{
                
                myBackgroundColor.ignoresSafeArea()
                
                
                
                ScrollView(){
                    VStack(){
                        
                        NavBarView()
                        SearchBarView()
                            .padding(.top,22)
                        Featured()
                            .padding(.bottom,60)
                        
                        
                        VStack{
                        Text("Category")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .semibold))
//                            .padding()
                       
                            ScrollView(.horizontal,showsIndicators: false){
                               
                            HStack{
                            NavigationLink(destination: KitchenEquipmentView()){
                                ZStack(alignment: .topTrailing){
                                ZStack(alignment: .bottom){
                                    ZStack{
                                   
                                    VStack(alignment: .leading){
                                        Text("Kitchen")
                                            .font(.system(size: 10))
                        //                   .fontWeight(.bold)
                                           .padding(.top,52)

                        //                    .frame(width: 100, height: 10)
                              
                                }
                                    .frame( width: 70,height: 77)
                        //        .shadow(radius: 3)
                                .background(.ultraThinMaterial)
                                .cornerRadius(10)
                            
                                .frame(width: 70.5,height: 80)
                                .shadow(radius: 3)
                                        Image("Kitchen")
                                            .resizable()
                                            .cornerRadius(10)
                                            .frame(width: 40,height: 40)
                                            .scaledToFit()
                                            .padding()
                                    }

                            }
                            }

                            }
                                
                                NavigationLink(destination: KitchenEquipmentView()){
                                    ZStack(alignment: .topTrailing){
                                    ZStack(alignment: .bottom){
                                        ZStack{
                                       
                                        VStack(alignment: .leading){
                                            Text("Garden")
                                                .font(.system(size: 10))
                            //                   .fontWeight(.bold)
                                               .padding(.top,52)

                            //                    .frame(width: 100, height: 10)
                                  
                                    }
                                        .frame( width: 70,height: 77)
                            //        .shadow(radius: 3)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                
                                    .frame(width: 70.5,height: 80)
                                    .shadow(radius: 3)
                                            Image("Garden")
                                                .resizable()
                                                .cornerRadius(10)
                                                .frame(width: 40,height: 40)
                                                .scaledToFit()
                                                .padding()
                                        }

                                }
                                }

                                }
                              
                                NavigationLink(destination: KitchenEquipmentView()){
                                    ZStack(alignment: .topTrailing){
                                    ZStack(alignment: .bottom){
                                        ZStack{
                                       
                                        VStack(alignment: .leading){
                                            Text("Games")
                                                .font(.system(size: 10))
                            //                   .fontWeight(.bold)
                                               .padding(.top,52)

                                  
                                    }
                                        .frame( width: 70,height: 77)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                
                                    .frame(width: 70.5,height: 80)
                                    .shadow(radius: 3)
                                            Image("Games")
                                                .resizable()
                                                .cornerRadius(10)
                                                .frame(width: 40,height: 40)
                                                .scaledToFit()
                                                .padding()
                                        }

                                }
                                }

                                }

                                NavigationLink(destination: FurnitureView()){
                                    ZStack(alignment: .topTrailing){
                                    ZStack(alignment: .bottom){
                                        ZStack{
                                       
                                        VStack(alignment: .leading){
                                            Text("Furniture")
                                                .font(.system(size: 10))
                                               .padding(.top,52)

                                  
                                    }
                                        .frame( width: 70,height: 77)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                
                                    .frame(width: 70.5,height: 80)
                                    .shadow(radius: 3)
                                            Image("Furniture")
                                                .resizable()
                                                .cornerRadius(10)
                                                .frame(width: 40,height: 40)
                                                .scaledToFit()
                                                .padding()
                                        }

                                }
                                }

                                }

                                
                                //5
                                NavigationLink(destination: KitchenEquipmentView()){
                                    ZStack(alignment: .topTrailing){
                                    ZStack(alignment: .bottom){
                                        ZStack{
                                       
                                        VStack(alignment: .leading){
                                            Text("Electonic Deivces")
                                                .font(.system(size: 10))
                                               .padding(.top,52)

                                  
                                    }
                                        .frame( width: 70,height: 77)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                
                                    .frame(width: 70.5,height: 80)
                                    .shadow(radius: 3)
                                            Image("Electonic")
                                                .resizable()
                                                .cornerRadius(10)
                                                .frame(width: 40,height: 40)
                                                .scaledToFit()
                                                .padding(.bottom,10)
                                        }

                                }
                                }

                                }

                                NavigationLink(destination: ContentView()){
                                    ZStack(alignment: .topTrailing){
                                    ZStack(alignment: .bottom){
                                        ZStack{
                                       
                                        VStack(alignment: .leading){
                                            Text("Sport")
                                                .font(.system(size: 10))
                                               .padding(.top,52)

                                  
                                    }
                                        .frame( width: 70,height: 77)
                                    .background(.ultraThinMaterial)
                                    .cornerRadius(10)
                                
                                    .frame(width: 70.5,height: 80)
                                    .shadow(radius: 3)
                                            Image("Sport")
                                                .resizable()
                                                .cornerRadius(10)
                                                .frame(width: 40,height: 40)
                                                .scaledToFit()
                                                .padding(.bottom,10)
                                        }

                                }
                                }

                                }
                            
                            
                            }
                       
                                
                            }
                        
                    }

                    VStack{
                        Text("Recently Viewed")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .semibold))
                        HStack{
                            ScrollView(.horizontal,showsIndicators: false){
                        HStack(spacing: 44){
                           
                            NavigationLink(destination: ContentView()){
                        ZStack(alignment: .topTrailing){
                            
                        ZStack(alignment: .bottom){
                            Image("CoffeeCorner")
                                .resizable()
                                .cornerRadius(10)
                                .frame(width: 170,height: 143)
                                .scaledToFit()
                                .padding(.bottom,66)
                            VStack(alignment: .leading){
                                Text("Coffee Corner")
        //
                                    .font(.system(size: 16))
                                   .fontWeight(.bold)
                                   .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                                
                //                    .frame(width: 100, height: 10)
                                   
                                HStack{
                                Text("65")
                                    .font(.caption)
                                    .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                //                    .padding()
                                    Text("SR")
                                        .font(.system(size: 9))
                                        .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                                }
                                
                            }
                            .padding()
                            .frame(width: 180, alignment: .leading)
                            
                        }
                        .frame( height: 220)
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                    
                        .frame(width: 152.5)
                        .shadow(radius: 3)
                        
                        Button{
                //            print("Added to faviortie")
                           
                            if image == "heart"{
                                image = "heart.fill"}
                            else{
                                image = "heart"

                            }
                        }label: {
                            Image(systemName: image)
                                .frame(width: 20, height: 20)
                                .padding(.top,180)
                                .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        }
                    }
        //                .padding()
                        }
                            
                            
                            
        //                    Furniture(name: "ComputerDisk", image: "ComputerDisk", price: 45),
                            ZStack(alignment: .topTrailing){
                                ZStack(alignment: .bottom){
                                    Image("ComputerDisk")
                                        .resizable()
                                        .cornerRadius(10)
                                        .frame(width: 170,height: 143)
                                        .scaledToFit()
                                        .padding(.bottom,66)
                                    VStack(alignment: .leading){
                                        Text("ComputerDisk")
                                            
                                            .font(.system(size: 16))
                                           .fontWeight(.bold)
                                        
                        //                    .frame(width: 100, height: 10)
                                           
                                        HStack{
                                        Text("46")
                                            .font(.caption)
                        //                    .padding()
                                            Text("SR")
                                                .font(.system(size: 9))
                                        }
                                        
                                    }
                                    .padding()
                                    .frame(width: 180, alignment: .leading)
                                    
                                }
                                .frame( height: 220)
                        //        .shadow(radius: 3)
                                .background(.ultraThinMaterial)
                                .cornerRadius(10)
                            
                                .frame(width: 152.5)
                                .shadow(radius: 3)
                                
                                Button{
                        //            print("Added to faviortie")
                                   
                                    if image == "heart"{
                                        image = "heart.fill"}
                                    else{
                                        image = "heart"

                                    }
                                }label: {
                                    Image(systemName: image)
                                        .frame(width: 20, height: 20)
                                        .padding(.top,180)
                                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                                }
                            }
        //                        .padding()
                            NavigationLink(destination: SelectItem()){
                                ZStack(alignment: .topTrailing){
                                ZStack(alignment: .bottom){
                                    Image("Mixer")
                                        .resizable()
                                        .cornerRadius(10)
                                        .frame(width: 170,height: 143)
                                        .scaledToFit()
                                        .padding(.bottom,66)
                                    VStack{
                                        Text("Mixer")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                                            .frame(width: 182.0, height: 30.0)
                                            .font(.system(size: 16))
//                                            .padding(.trailing,100)
                        //                    .frame(width: 100, height: 10)
                                           
                                        HStack{
                                        Text("50")
                                            .font(.caption)
                                            .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                        //                    .padding()
                                            Text("SR")
                                                .font(.system(size: 9))
                                                .foregroundColor(Color(red: 0.0, green: 0, blue: 0.14))
                                        }
                                        
                                    }
                                    .padding(.trailing,100)
                                    .frame(width: 180)
                                    
                                }
                                .frame( height: 220)
                        //        .shadow(radius: 3)
                                .background(.ultraThinMaterial)
                                .cornerRadius(10)
                            
                                .frame(width: 152.5)
                                .shadow(radius: 3)
                                
                                Button{
                        //            print("Added to faviortie")
                                   
                                    if image == "heart"{
                                        image = "heart.fill"}
                                    else{
                                        image = "heart"

                                    }
                                }label: {
                                    Image(systemName: image)
                                        .frame(width: 20, height: 20)
                                        .padding(.top,180)
                                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                                }
                                }}
                                   

                            ZStack(alignment: .topTrailing){
                            ZStack(alignment: .bottom){
                                Image("TVuint")
                                    .resizable()
                                    .cornerRadius(10)
                                    .frame(width: 170,height: 143)
                                    .scaledToFit()
                                    .padding(.bottom,66)
                                VStack(alignment: .leading){
                                    Text("TV uint")
                                        
                                        .font(.system(size: 16))
                                       .fontWeight(.bold)
                                    
                    //                    .frame(width: 100, height: 10)
                                       
                                    HStack{
                                    Text("55")
                                        .font(.caption)
                    //                    .padding()
                                        Text("SR")
                                            .font(.system(size: 9))
                                    }
                                    
                                }
                                .padding()
                                .frame(width: 180, alignment: .leading)
                                
                            }
                            .frame( height: 220)
                    //        .shadow(radius: 3)
                            .background(.ultraThinMaterial)
                            .cornerRadius(10)
                        
                            .frame(width: 152.5)
                            .shadow(radius: 3)
                            
                            Button{
                    //            print("Added to faviortie")
                               
                                if image == "heart"{
                                    image = "heart.fill"}
                                else{
                                    image = "heart"

                                }
                            }label: {
                                Image(systemName: image)
                                    .frame(width: 20, height: 20)
                                    .padding(.top,180)
                                    .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            }
                        }
                            
                            
                        } .padding()
                        
                            }
                            
                        }
                        }
                        
                    }
                    VStack{
                        Text("Product for you")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .semibold))
//                            .padding()
                        ScrollView(.horizontal,showsIndicators: false){
                            HStack{
                                ForEach(0..<4){item in
                                    ProductForYouView()
                                    
                                }
                            }
//
//
                        }
                        
                    }
                   
                    }
              
              
//                padding(.top,120)
                .padding()       }
         

//            .padding(.trailing)
//
//            .padding(.leading)
        }
                
        }
       
    
        }
        




struct SearchBarView: View{
    @State private var search: String = ""
    
    var body: some View{
        HStack{
            HStack{
                Image(systemName: "magnifyingglass")
                    .padding(.trailing,8)
                    .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                TextField("Search", text: $search )
                    .overlay(
                        Image(systemName: "xmark.circle")
                            .padding(.leading,252)
                            .offset(x:10)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .onTapGesture {
                                search = ""
                            }
                    )
                
            }
            .padding()
            
            .background(Color.white)
            .cornerRadius(12.0)
            .padding(.horizontal)
            
            
        }
        
    }
}

struct NavBarView: View{
    var body: some View{
  
        HStack{
            Image(systemName: "mappin.and.ellipse")
                .padding()
                .font(.system(size: 21))
                .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
            VStack{
                Text("Current Location")
                    .fontWeight(.thin)
                

            }
            Spacer()
            Button(action: {
                
            }, label:{
                Image(systemName: "bell.badge")
                    .padding()
            })
        }
   
        .accentColor(Color(red: -0.056, green: 0.168, blue: 0.3))
        .font(.headline)
        .background(
            Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1).ignoresSafeArea( edges: .top))
     
    }
    
}


struct Featured: View{
    
    private var numberOfImages = 14
    private let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    @State private var currentIndex = 0
    var body: some View{
        
        VStack(spacing:1){
            
            Text("Featured")
                .frame(maxWidth: 375, alignment: .leading)
                .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                .font(.system(size: 22,weight: .semibold))
            
            
            
            HStack(alignment:.center, spacing: 38){
                
                
                GeometryReader{ proxy in
                    TabView(selection: $currentIndex){
                        ForEach(8..<numberOfImages){ num in
                            Image("\(num)")
                                .resizable()
                                .scaledToFill()
                                .tag(num)
             
                                .overlay(Color.black
                                            .opacity(0.6))
                                .tag(num)
                            
                            
                        }
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .frame(width: 345, height: 197,alignment: .center)
                    .padding()
                    
                }
                .padding(.bottom,159)
                .onReceive(timer, perform: {
                    _ in
                    withAnimation{
                        currentIndex = currentIndex < numberOfImages ? currentIndex + 1:0
                    }   })
            }
            
            
            
            
            
            
            
            
        }
        
    }
}




struct RecentlyView: View{
    var body: some View{
        
        ScrollView(.horizontal,showsIndicators: false){
            HStack{
        ForEach(productList, id: \.id){ Product in ProductShape(Product: Product)
            
        }
        
    .padding()
            }
            
        }
        
    }
}


struct ProductForYouView:View{
    var body: some View{
        
        
        ScrollView(.horizontal,showsIndicators: false){
            HStack{
        ForEach(FurnitureList, id: \.id){ Furniture in FurnitureShape(Furniture: Furniture)
            
        }
    .padding()
            }
            
        }
        
        
        
    }
}


struct HomeView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        HomeView()
    }
}

