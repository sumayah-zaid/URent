//
//  OrdersView.swift
//  UrentLama
//
//  Created by Lama Doughan on 29/01/2022.
//

import SwiftUI

struct OrdersView: View {
    var body: some View {
        
        VStack(spacing:16){
            ZStack{
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(width: 326, height: 80)
                
                HStack(spacing:28){
                    HStack{
                        Image("nikon_L")
                        
                        VStack(alignment: .leading,spacing: 8){
                            Text("Camera Nikon Z6")
                                .font(.system(size: 17))
                            
                            Text("1 Feb - 21 Feb")
                                .font(.system(size: 14))
                        }
                    }.padding(.leading)
                    
                    VStack(spacing:8){
                        Text("Accepted")
                            .foregroundColor(Color.green)
                        
                        Image(systemName: "message.fill")
                            .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                    }.padding(.trailing)
                }.frame(maxWidth:.infinity)
            }
            
            ZStack{
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(width: 326, height: 80)
                
                HStack(spacing:28){
                    HStack{
                        Image("dj_L")
                        
                        VStack(alignment: .leading,spacing: 8){
                            Text("DJ Equalizer Set\t")
                                .font(.system(size: 17))
                            Text("20 Jan - 25 Jan")
                                .font(.system(size: 14))
                        }
                    }.padding(.leading)
                    
                    Text("Rejected")
                        .foregroundColor(Color.red)
                        .padding(.trailing)
                }.frame(alignment: .leading)
            }
            
            ZStack{
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(width: 326, height: 80)
                
                HStack(spacing:62){
                    HStack{
                        Image("bike_L")
                        
                        VStack(alignment: .leading,spacing: 8){
                            Text("Bike")
                                .font(.system(size: 17))
                            Text("2 May - 12 May")
                                .font(.system(size: 14))
                        }
                    }.padding(.leading)
                    
                    VStack(spacing:8){
                        Text("Accepted")
                            .foregroundColor(Color.green)
                        
                        Image(systemName: "message.fill")
                            .foregroundColor(Color(red: 0.348, green: 0.466, blue: 0.596))
                    }.padding(.trailing)
                }
            }
            
            ZStack{
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(width: 326, height: 80)
                
                HStack(spacing:62){
                    HStack{
                        Image("carpentry_L")
                        
                        VStack(alignment: .leading,spacing: 8){
                            Text("Carpentry Kit")
                                .font(.system(size: 17))
                            Text("13 May - 16 May")
                                .font(.system(size: 14))
                        }
                    }.padding(.leading)
                    
                    Text("Pending")
                        .foregroundColor(Color.yellow)
                        .padding(.trailing)
                }
            }
        }.padding(.top)
    }
}

struct OrdersView_Previews: PreviewProvider {
    static var previews: some View {
        OrdersView()
    }
}

