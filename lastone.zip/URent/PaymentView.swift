//
//  PaymentView.swift
//  Homepage
//
//  Created by Waad Alsaif on 26/01/2022.
//

import SwiftUI
import iPaymentButton

struct PaymentView: View {

  //  @State private var SubTotoal: Double
    @EnvironmentObject var UserModel: account

    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    var body: some View {
            ZStack{
                myBackgroundColor.ignoresSafeArea()
        
                    
                VStack{
                    Text("Payment method")
                        .frame(maxWidth: 375, alignment: .center)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        .font(.system(size: 30,weight: .semibold))
                        .padding()
                    
                    Text(UserModel.account.name)
                        .frame(maxWidth: 375, alignment: .leading)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        .font(.system(size: 30,weight: .semibold))
                        .padding()
                    
                    HStack{
                    Text("Sub Total")
                        .frame(maxWidth: 375, alignment: .leading)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        .font(.system(size: 22,weight: .semibold))
                        .padding(.leading)

                        Text("73 SR")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .light))
                    }
                    HStack{
                    Text("Insurance")
                        .frame(maxWidth: 375, alignment: .leading)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        .font(.system(size: 22,weight: .semibold))
                        .padding(.leading)
                        Text("20 SR")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .light))
                    }
                    HStack{
                    Text("Total")
                        .frame(maxWidth: 375, alignment: .leading)
                        .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                        .font(.system(size: 22,weight: .semibold))
                        .padding(.leading)
                        Text("93 SR")
                            .frame(maxWidth: 375, alignment: .leading)
                            .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                            .font(.system(size: 22,weight: .light))
                    }
                }.padding(.bottom,200)
                    
               
                iPaymentButton{
                    UserModel.account.name = "Waad"
                    
            iPaymentButton.applePayDemo()
                } .padding(.top,399)
                    .frame(width: 299, height: 44)
                    
                }
            .navigationBarBackButtonHidden(true)
                       .navigationBarItems(leading:
                                            HStack{
                            Button(action : {
                           self.mode.wrappedValue.dismiss()
            
                       }){
                         
                       
            VStack{
                     
                     Image(systemName: "chevron.backward")
                         .foregroundColor(Color(hue: 0.921, saturation: 0.055, brightness: 0.415))
                      
                         
                         
                     
            }
            
            }
                           Text("Payment")
                               .font(.headline)
                               .fontWeight(.bold)
                               .padding(.leading, 120.0)
                        
                               
                                           })
        
    }
            
    }
    


struct PaymentView_Previews: PreviewProvider {
    static var previews: some View {
        PaymentView()
    }
}
