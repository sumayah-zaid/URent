//
//  Profile.swift
//  Reegister
//
//  Created by Danya T on 22/06/1443 AH.
//

import SwiftUI

struct Profile: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @EnvironmentObject var UserModel: account
//    @EnvironmentObject var UserModel2: UploadInfo
    @State var language = false
    @State var out = false
    @State private var image = "heart"
    @State var edit = false
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20),GridItem(.adaptive(minimum: 160), spacing: 20)]
    var body: some View {
            ZStack{
                myBackgroundColor
                    .ignoresSafeArea()
                VStack{
                    Divider()
                    HStack{
                        Image(uiImage: UserModel.account.image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 90, height: 90)
                            .clipShape(Circle())
                            .padding()
                        Spacer()
                            .frame(width: 1.0)
                        VStack(alignment: .leading, spacing: 8){
                            
                            Text(UserModel.account.name)
                                .font(.title2)
                                .multilineTextAlignment(.leading)
                            Text(UserModel.account.location)
                                .multilineTextAlignment(.leading)
                           

                            HStack{
                                Image(systemName: "star")
                                    .foregroundColor(Color.yellow)
                                Image(systemName: "star").foregroundColor(Color.yellow)
                                Image(systemName: "star").foregroundColor(Color.yellow)
                                Image(systemName: "star").foregroundColor(Color.yellow)
                                Image(systemName: "star").foregroundColor(Color.yellow)
                                
                            }
                        }
                        ZStack {
                            NavigationLink(
                                destination: Edit(),
                                isActive: $edit,
                                label: {
                                    
                                })
                            NavigationLink(
                                destination: Language(),
                                isActive: $language,
                                label: {
                                    
                                })
//                            NavigationLink(
//                                destination: Singup(),
//                                isActive: $out,
//                                label: {
//                                    
//                                })
                            Menu {
                                Button {
                                    language=true
                                } label: {
                                    Text("Language")
                                }
                                Button {
                                    edit = true
                                } label: {
                                    Text("Edit Profile")
                                }
                                Button {
                                    out=true
                                } label: {
                                    Label("Log Out", systemImage: "rectangle.portrait.and.arrow.right")
                                }
                                
                            } label: {
                                Image(systemName: "gearshape").font(.system(size:20)) .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.286, opacity: 100.0))
                            }
                        }.offset(x:25,y:-40)
                        Spacer()
                    }
                    Divider()
                    ScrollView {
                        Text("My Products")   .font(.title3)
                            .fontWeight(.bold)
                            .offset(x:-100)
                            .foregroundColor(Color(red: 0.0, green: 0.161, blue: 0.286, opacity: 100.0))
                        LazyVGrid(columns: columns, spacing: 10){
                            ForEach(0..<UserModel.account.myUpload.count , id: \.self) { index in
                                ZStack(alignment: .topTrailing){
                                ZStack(alignment: .bottom){
                                  Image(uiImage: UserModel.account.myUpload[index].image)
                                    .resizable()
                                    .cornerRadius(10)
                                    .frame(width: 170,height: 143)
                                    .scaledToFit()
                                    .padding(.bottom,66)
                                  VStack(alignment: .leading){
                                    Text(UserModel.account.myUpload[index].productName)
                                      .font(.system(size: 16))
                                      .fontWeight(.bold)
                            //          .frame(width: 100, height: 10)
                                    HStack{
                                    Text(UserModel.account.myUpload[index].price)
                                      .font(.caption)
                            //          .padding()
                                      Text("SR")
                                        .font(.system(size: 9))
                                    }
                                  }
                                  .padding()
                                  .frame(width: 180, alignment: .leading)
                                }
                                .frame( height: 220)
                            //    .shadow(radius: 3)
                                .background(.ultraThinMaterial)
                                .cornerRadius(10)
                                .frame(width: 152.5)
                                .shadow(radius: 3)
                                Button{
                            //      print(“Added to faviortie”)
                                  if image == "heart"{
                                    image = "heart.fill"}
                                  else{
                                    image = "heart"
                                  }
                                }label: {
                                  Image(systemName: image)
                                    .frame(width: 20, height: 20)
                                    .padding(.top,180)
                                    .foregroundColor(Color(red: -0.056, green: 0.168, blue: 0.3))
                                }
                              }
                            }
                        }
                    }
                }.padding( .horizontal, 10.0)
                
                
            }
            
            
            .navigationBarTitle("Profile",displayMode: .inline)
            .navigationBarBackButtonHidden(true)
        
        
    }
}


struct Profile_Previews: PreviewProvider {
    
    static var previews: some View {
        Profile()
    }
}

struct Language: View {
    @State private var selectedLanguage = "English"
    let languages = ["English", " "]
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    Picker("", selection: $selectedLanguage) {
                        ForEach(languages, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(.wheel)
                }
            }
            
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Select Language")
                        .font(.largeTitle.bold())
                        .frame(width: 500.0) .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        .accessibilityAddTraits(.isHeader)
                    
                }
            }
        }
    }
}
