//
//  URentApp.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

@main
struct URentApp: App {
    
//    @StateObject var Model : account = .init()
    @StateObject var Model : account = .init()
    @StateObject var Model2 : upload = .init()
    var body: some Scene {
        WindowGroup {
            WalkThrough()
                .environmentObject(Model)
                .environmentObject(Model2)
        }
    }
}
