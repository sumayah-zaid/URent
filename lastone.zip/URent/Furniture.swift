//
//  FurnitureProduct.swift
//  test
//
//  Created by Waad Alsaif on 28/01/2022.
//

import Foundation

struct Furniture: Identifiable{
    var id = UUID()
    var name:  String
    var image: String
    var price: Int
    
}

var FurnitureList = [Furniture(name: "Gaming Chair", image: "gamingChair", price: 70),
                     Furniture(name: "Coffee Corner", image: "CoffeeCorner", price: 86),
                     Furniture(name: "ComputerDisk", image: "ComputerDisk", price: 45),
                     Furniture(name: "TV uint", image: "TVuint", price: 66),
                     Furniture(name: "LazyChair", image: "LazyChair", price: 66),
                     Furniture(name: "Sofa", image: "Sofa", price: 66),
                     
]

