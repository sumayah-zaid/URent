//
//  SignIn.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

struct SignIn: View {
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)

    @State private var phone = ""
    @State private var pass1 = ""
    @State private var forgot = false
    @State var errorMessage1 = ""
    @State var errorMessage2 = ""
   
    var body: some View {
      
            ZStack{
                myBackgroundColor.ignoresSafeArea()
               
                   
                VStack{
                    
                    Spacer()
                        .frame( height: 19.0)
                        VStack(alignment: .leading,spacing: 16) {
                           
                          
                            HStack{
                            Text("Phone Number")
                                .font(.title3)
                            .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                                Text(errorMessage1).font(.callout)
                                .foregroundColor(Color.red)}
                            TextField("Enter Phone Number...", text: $phone)
                                .frame(width: 326.0, height: 37.0)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            HStack{
                            Text("Password")
                                .font(.title3)
                                .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                                Text(errorMessage2)
                                        .font(.callout)
                                    .foregroundColor(Color.red)}
                            TextField("Enter Password...", text: $pass1)
                                .frame(width: 326.0, height: 37.0)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                           
                            Button("Forgot Password?") {
                                forgot.toggle()
                            }
                            .sheet(isPresented: $forgot) {
                                forgotPassword(forgotPage: $forgot)
                            }
                        }.padding(.top, 32.0)
                               
                    Spacer()
                  
                       
                        Button{
                                        
                                    } label: {
                                        ZStack{
                                        Text("Sign Up with Apple")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                            .fontWeight(.semibold)
                                            .padding()
                                            .padding(.horizontal,30)
                                            .background(Color.black
                                                    .cornerRadius(8)
                                                    .frame(width: 299, height: 44)
                                            )
                                            Image(systemName:"applelogo").foregroundColor(Color.white).offset(x:-90)                                }
                                    }
//                    NavigationLink(destination: Code(isShowingRegisterationForm: $is))
//                            {
//                                        ZStack{
//                                    Text("Sign In")
//                                        .font(.headline)
//                                        .foregroundColor(.white)
//                                        .fontWeight(.semibold)
//                                        .padding()
//                                        .padding(.horizontal,30)
//                                        .background(
//                                            Color(red: 0.17, green: 0.325, blue: 0.471)
//                                                .cornerRadius(8)
//                                                .frame(width: 299, height: 44)
//                                        )
//
//                                }
//                    }
                         
                }.padding(.horizontal, 32.0)
                }
                    
            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Sign In").padding(.top, 8.0)
                        .font(.largeTitle.bold())
                        .frame(width: 200.0) .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        .accessibilityAddTraits(.isHeader)
     
       }
            
      }
     
  }

}
struct forgotPassword: View {
    
    @Binding var forgotPage: Bool
    @State private var num1 = ""
    @State private var num2 = ""
    @State private var num3 = ""
    @State private var num4 = ""
    var body: some View {
        NavigationView{
          
                
                VStack{
                    Text("Forgot Password").font(.largeTitle).fontWeight(.bold).foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                    
                    Spacer()
                        .frame(height: 50.0)
                 
                    Text("Enter the 4 digits code\nsent to your phone ")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        .font(.title2)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                       
                 
                 HStack
                    {
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                    }
                   
                    Spacer().frame(height: 350.0)
                    
                    
                    NavigationLink(destination:rePassword(forgotPage: self.$forgotPage)){
                                        ZStack{
                                    Text("Next")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                        .padding()
                                        .padding(.horizontal,30)
                                        .background(
                                            Color(red: 0.17, green: 0.325, blue: 0.471)
                                                .cornerRadius(8)
                                                .frame(width: 299, height: 44)
                                        )
                                        
                                }
                    }
                    
                    
                    }
                }
              
                
            
                
        .navigationBarItems(trailing:
                    Button(action: {
            self.forgotPage=false
                    }){
                        Text("Done")
                    })
           }
   }


struct rePassword: View {
    
    @Environment(\.presentationMode) var presentationMode

    @Binding var forgotPage: Bool
    @State private var pass1 = ""
    @State private var pass2 = ""
        var body: some View {
            VStack(alignment: .leading,spacing: 16){
              
                Text("New Password")
                    .font(.title3)
                    .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                   
                TextField("Enter Password...", text: $pass1)
                    .frame(width: 326.0, height: 37.0)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Confirm Password")
                    .font(.title3)
                    .bold() .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                   
                TextField("Re Password...", text: $pass2)
                    .frame(width: 326.0, height: 37.0)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Spacer()
               }.padding(.horizontal, 32.0)
            .navigationBarItems(trailing:
                Button(action: {
                    
                    self.forgotPage = false
                }){
                    Text("Done")
                }
            )
        }
}
           
   




struct SignIn_Previews: PreviewProvider {
    static var previews: some View {
        SignIn()
    }

}
