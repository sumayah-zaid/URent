//
//  Code.swift
//  URent
//
//  Created by Danya T on 25/06/1443 AH.
//

import SwiftUI

struct Code: View {
    @Environment(\.presentationMode) private var presentationMode
    let myBackgroundColor = Color(.sRGB, red: Double(241)/255, green: Double(241)/255, blue: Double(241)/255, opacity: 1)
    @Binding var isShowingRegisterationForm : Bool
    @State var Next = false
    @State private var num1 = ""
    @State private var num2 = ""
    @State private var num3 = ""
    @State private var num4 = ""
    @EnvironmentObject var UserModel: account

    var body: some View {
       
        
            ZStack{
                myBackgroundColor.ignoresSafeArea()
               
                  
                   
                VStack{
                    Spacer()
                        .frame(height: 32)
                    Text("Verification\nCode")
                    .font(.largeTitle.bold())
                    .multilineTextAlignment(.center)
                    .frame(width: 500, height: 100).foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                    
                    Spacer()
                        .frame(height: 100.0)
                 
                    Text("Enter the 4 digits code\nsent to your phone ")
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.008, green: 0.165, blue: 0.29, opacity: 100.0))
                        .font(.title2)
                        .multilineTextAlignment(.center)
                    
                    
                    Spacer()
                        .frame(height: 32.0)
                 
                 HStack
                    {
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                        ZStack{
                            Rectangle().frame(width:60,height:60).foregroundColor(Color(hue: 1.0, saturation: 0.0, brightness: 0.852)).cornerRadius(5)
                            TextField("",text:$num1).frame(width:20,height:10)
                        
                    }
                    }
                   
                   
                      Spacer()
                    Button(action:{
                        isShowingRegisterationForm = false
                    }
                           ,label:{
                                        ZStack{
                                    Text("Next")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .fontWeight(.semibold)
                                        .padding()
                                        .padding(.horizontal,30)
                                        .background(
                                            Color(red: 0.17, green: 0.325, blue: 0.471)
                                                .cornerRadius(8)
                                                .frame(width: 299, height: 44)
                                        )
                                        
                                }
//                        NavigationLink(
//                                        destination: ContentView(),
//                                        isActive: $Next,
//                                        label: {
//
//                                        })
                    })
                    
                    }
                        
                       
                         
                }.padding(.horizontal, 32.0)
                
                    
            .navigationBarTitle("", displayMode: .inline)

     
       
            
      
     
  }
}

struct Code_Previews: PreviewProvider {
    static var previews: some View {
        Code(isShowingRegisterationForm: .constant(true))
    }
}
